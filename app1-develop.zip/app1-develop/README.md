# app1
Webratio basic flow model
A fully integrated vdi with linux ubuntu and the comunity suit of webratio + talend ESB

Git should be also integrated for allowing people to contribute.
